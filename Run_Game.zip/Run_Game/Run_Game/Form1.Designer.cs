﻿namespace Run_Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Zombei = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.n5 = new System.Windows.Forms.PictureBox();
            this.n4 = new System.Windows.Forms.PictureBox();
            this.n3 = new System.Windows.Forms.PictureBox();
            this.n2 = new System.Windows.Forms.PictureBox();
            this.n1 = new System.Windows.Forms.PictureBox();
            this.n6 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.shaswar = new System.Windows.Forms.PictureBox();
            this.fire = new System.Windows.Forms.PictureBox();
            this.Batman = new System.Windows.Forms.PictureBox();
            this.sham = new System.Windows.Forms.PictureBox();
            this.manhole = new System.Windows.Forms.PictureBox();
            this.zmbmsg = new System.Windows.Forms.PictureBox();
            this.batmsg = new System.Windows.Forms.PictureBox();
            this.gamover = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Zombei)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.n5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.n4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.n3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.n2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.n1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.n6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shaswar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fire)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Batman)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sham)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.manhole)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zmbmsg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.batmsg)).BeginInit();
            this.SuspendLayout();
            // 
            // Zombei
            // 
            this.Zombei.Image = ((System.Drawing.Image)(resources.GetObject("Zombei.Image")));
            this.Zombei.Location = new System.Drawing.Point(-200, 321);
            this.Zombei.Name = "Zombei";
            this.Zombei.Size = new System.Drawing.Size(200, 200);
            this.Zombei.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Zombei.TabIndex = 1;
            this.Zombei.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(500, 356);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(493, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(500, 356);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pictureBox3.Location = new System.Drawing.Point(0, 343);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(983, 12);
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            // 
            // n5
            // 
            this.n5.BackColor = System.Drawing.Color.Yellow;
            this.n5.Location = new System.Drawing.Point(790, 343);
            this.n5.Name = "n5";
            this.n5.Size = new System.Drawing.Size(100, 12);
            this.n5.TabIndex = 11;
            this.n5.TabStop = false;
            // 
            // n4
            // 
            this.n4.BackColor = System.Drawing.Color.Yellow;
            this.n4.Location = new System.Drawing.Point(596, 343);
            this.n4.Name = "n4";
            this.n4.Size = new System.Drawing.Size(100, 12);
            this.n4.TabIndex = 12;
            this.n4.TabStop = false;
            // 
            // n3
            // 
            this.n3.BackColor = System.Drawing.Color.Yellow;
            this.n3.Location = new System.Drawing.Point(400, 343);
            this.n3.Name = "n3";
            this.n3.Size = new System.Drawing.Size(100, 13);
            this.n3.TabIndex = 13;
            this.n3.TabStop = false;
            // 
            // n2
            // 
            this.n2.BackColor = System.Drawing.Color.Yellow;
            this.n2.Location = new System.Drawing.Point(219, 344);
            this.n2.Name = "n2";
            this.n2.Size = new System.Drawing.Size(100, 12);
            this.n2.TabIndex = 14;
            this.n2.TabStop = false;
            // 
            // n1
            // 
            this.n1.BackColor = System.Drawing.Color.Yellow;
            this.n1.Location = new System.Drawing.Point(23, 344);
            this.n1.Name = "n1";
            this.n1.Size = new System.Drawing.Size(100, 12);
            this.n1.TabIndex = 15;
            this.n1.TabStop = false;
            // 
            // n6
            // 
            this.n6.BackColor = System.Drawing.Color.Yellow;
            this.n6.Location = new System.Drawing.Point(967, 344);
            this.n6.Name = "n6";
            this.n6.Size = new System.Drawing.Size(100, 12);
            this.n6.TabIndex = 16;
            this.n6.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(810, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(90, 73);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 17;
            this.pictureBox4.TabStop = false;
            // 
            // shaswar
            // 
            this.shaswar.Image = ((System.Drawing.Image)(resources.GetObject("shaswar.Image")));
            this.shaswar.Location = new System.Drawing.Point(611, 262);
            this.shaswar.Name = "shaswar";
            this.shaswar.Size = new System.Drawing.Size(119, 117);
            this.shaswar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.shaswar.TabIndex = 23;
            this.shaswar.TabStop = false;
            // 
            // fire
            // 
            this.fire.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fire.Image = ((System.Drawing.Image)(resources.GetObject("fire.Image")));
            this.fire.Location = new System.Drawing.Point(442, 500);
            this.fire.Name = "fire";
            this.fire.Size = new System.Drawing.Size(100, 50);
            this.fire.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fire.TabIndex = 24;
            this.fire.TabStop = false;
            this.fire.Visible = false;
            // 
            // Batman
            // 
            this.Batman.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Batman.Image = ((System.Drawing.Image)(resources.GetObject("Batman.Image")));
            this.Batman.Location = new System.Drawing.Point(133, 362);
            this.Batman.Name = "Batman";
            this.Batman.Size = new System.Drawing.Size(200, 200);
            this.Batman.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Batman.TabIndex = 25;
            this.Batman.TabStop = false;
            // 
            // sham
            // 
            this.sham.Image = ((System.Drawing.Image)(resources.GetObject("sham.Image")));
            this.sham.Location = new System.Drawing.Point(475, 311);
            this.sham.Name = "sham";
            this.sham.Size = new System.Drawing.Size(43, 31);
            this.sham.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.sham.TabIndex = 26;
            this.sham.TabStop = false;
            // 
            // manhole
            // 
            this.manhole.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.manhole.Image = ((System.Drawing.Image)(resources.GetObject("manhole.Image")));
            this.manhole.Location = new System.Drawing.Point(837, 459);
            this.manhole.Name = "manhole";
            this.manhole.Size = new System.Drawing.Size(63, 91);
            this.manhole.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.manhole.TabIndex = 22;
            this.manhole.TabStop = false;
            this.manhole.Visible = false;
            // 
            // zmbmsg
            // 
            this.zmbmsg.Image = ((System.Drawing.Image)(resources.GetObject("zmbmsg.Image")));
            this.zmbmsg.Location = new System.Drawing.Point(323, 166);
            this.zmbmsg.Name = "zmbmsg";
            this.zmbmsg.Size = new System.Drawing.Size(141, 60);
            this.zmbmsg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.zmbmsg.TabIndex = 27;
            this.zmbmsg.TabStop = false;
            // 
            // batmsg
            // 
            this.batmsg.Image = ((System.Drawing.Image)(resources.GetObject("batmsg.Image")));
            this.batmsg.Location = new System.Drawing.Point(390, 286);
            this.batmsg.Name = "batmsg";
            this.batmsg.Size = new System.Drawing.Size(203, 80);
            this.batmsg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.batmsg.TabIndex = 28;
            this.batmsg.TabStop = false;
            // 
            // gamover
            // 
            this.gamover.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gamover.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gamover.ForeColor = System.Drawing.Color.Red;
            this.gamover.Location = new System.Drawing.Point(164, 0);
            this.gamover.Name = "gamover";
            this.gamover.Size = new System.Drawing.Size(582, 263);
            this.gamover.TabIndex = 30;
            this.gamover.Text = "Game Over";
            this.gamover.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.gamover.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Uighur", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Lime;
            this.label1.Location = new System.Drawing.Point(23, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 36);
            this.label1.TabIndex = 31;
            this.label1.Text = "Heart: %100";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Yellow;
            this.label2.Location = new System.Drawing.Point(23, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 17);
            this.label2.TabIndex = 32;
            this.label2.Text = "Point:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(982, 653);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gamover);
            this.Controls.Add(this.batmsg);
            this.Controls.Add(this.zmbmsg);
            this.Controls.Add(this.sham);
            this.Controls.Add(this.Batman);
            this.Controls.Add(this.fire);
            this.Controls.Add(this.shaswar);
            this.Controls.Add(this.manhole);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.n6);
            this.Controls.Add(this.n1);
            this.Controls.Add(this.n2);
            this.Controls.Add(this.n3);
            this.Controls.Add(this.n4);
            this.Controls.Add(this.n5);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Zombei);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Run";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.Zombei)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.n5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.n4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.n3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.n2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.n1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.n6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shaswar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fire)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Batman)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sham)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.manhole)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zmbmsg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.batmsg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox Zombei;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox n5;
        private System.Windows.Forms.PictureBox n4;
        private System.Windows.Forms.PictureBox n3;
        private System.Windows.Forms.PictureBox n2;
        private System.Windows.Forms.PictureBox n1;
        private System.Windows.Forms.PictureBox n6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox shaswar;
        private System.Windows.Forms.PictureBox fire;
        private System.Windows.Forms.PictureBox Batman;
        private System.Windows.Forms.PictureBox sham;
        private System.Windows.Forms.PictureBox manhole;
        private System.Windows.Forms.PictureBox zmbmsg;
        private System.Windows.Forms.PictureBox batmsg;
        private System.Windows.Forms.Label gamover;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

