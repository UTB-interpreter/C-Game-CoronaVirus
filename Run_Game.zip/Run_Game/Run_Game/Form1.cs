﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net.NetworkInformation;

namespace Run_Game
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int i = 0;
        int j = 18;
        void moveActor(int x, int y)
        {
            i = y;
            i = i - j;
            j--;
            Batman.Location = new Point(x + 5, i);
            if (380 <= Batman.Location.Y)
            {
                jump = false;
                i = 0;
                j = 18;
            }
        }

        int checkB(char xy)
        {
            if (xy == 'x')
            {
                return Batman.Location.X;
            }else
            {
                return Batman.Location.Y;
            }
        }
        int cont = 1000;
        bool jump = false;

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            zmbmsg.Visible = false;
            if (e.KeyCode == Keys.Space && game)
            {
                if (Batman.Location.X < 450)
                {
                    jump = true;
                }
            }
        }
        void Zombiea()
        {
            if (Zombei.Location.X + 200 > fire.Location.X || Zombei.Location.X + 200 > manhole.Location.X)
            {
                if (Zombei.Location.Y > 280)
                {
                    Zombei.Location = new Point(Zombei.Location.X + 1, Zombei.Location.Y - 2);
                }
            }
            else
            {
                if (Zombei.Location.Y != 380)
                {
                    Zombei.Location = new Point(Zombei.Location.X - 1, Zombei.Location.Y + 2);
                }
            }

        }

        void bat(int speed)
        {
            if (Batman.Location.X < 300)
            {
                sham.Location = new Point(Batman.Location.X, Batman.Location.Y + 5);
            }
            else
            {
                sham.Location = new Point(sham.Location.X, sham.Location.Y);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        void enmy(int actor, int y, int x)
        {
            if (actor == 1) // manhole
            {
                if (manhole.Location.X < -50) 
                {
                    manhole.Location = new Point(x, 460);
                    manhole.Visible = true;
                }
                
            }else
            {
                if (fire.Location.X < -50)
                {
                    fire.Location = new Point(x, 490);
                    fire.Visible = true;
                }
            }
        }


        void moveEnemy(int speed)
        {
            if (!started)
            {
                manhole.Location = new Point(1000, 460);
                fire.Location = new Point(1500, 490);
            }
            if (started)
            {
                if (fire.Location.X > -200)
                {
                    fire.Location = new Point(fire.Location.X - speed, fire.Location.Y);
                }

                if (manhole.Location.X > -200)
                {
                    manhole.Location = new Point(manhole.Location.X - speed, manhole.Location.Y);
                }
            }
        }

        bool game = true;

        void end()
        {
            if (Zombei.Location.X < 1050)
            {
                Zombei.Location = new Point(Zombei.Location.X + 1, Zombei.Location.Y);
                if (Zombei.Location.X + 100 >= sham.Location.X)
                {
                    sham.Location = new Point(Zombei.Location.X + 85, +335 + Zombei.Height / 2);
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (game)
            {
                start();
                moveline(3);
                bat(3);
                moveEnemy(3);
                Zombiea();
            }
            else
            {
                end();
            }

            Random random = new Random();
            int r2 = random.Next(1,3);
            int r1 = random.Next(1000, 1400);
            enmy(r2, 460, r1);

            if (jump)
            {
                cont--;

                int x = checkB('x');
                int y = checkB('y');

                moveActor(x, y);

                if (cont < 0)
                {
                    cont = 1000;
                }
            }

            if (Batman.Location.Y == 380 && Batman.Location.X > 300 && game)
            {
                Batman.Location = new Point(Batman.Location.X-2, Batman.Location.Y);
            }

            if (Batman.Bounds.IntersectsWith(fire.Bounds) || Batman.Bounds.IntersectsWith(manhole.Bounds))
            {
                
                if (heart > 0)
                {
                    heart--;
                }
                else
                {
                    game = false;
                    gamover.Visible = true;
                    Batman.Height = 100;
                    Batman.Location = new Point(Batman.Location.X,250);
                    manhole.Visible = false;
                    fire.Visible = false;
                    Batman.Image = Image.FromFile(@"Images\losser.png");
                }
                label1.Text = "Heart: %"+heart;
            }

            if (heart > 0 && point < 10000)
            {
                point++;   
            }

            if (point == 10000)
            {
                gamover.Text = "You Can Not Save The World By Running Wear Mask Batman!";
                gamover.Visible = true;
            }

            label2.Text = "Points ---> " + point;

        }

        int heart = 100;
        int point = 0;
        bool started = false;

        void start()
        {



            batmsg.Location = new Point(sham.Location.X,sham.Location.Y-75);
            zmbmsg.Location = new Point(Zombei.Location.X+25,Zombei.Location.Y-25);
            if (Batman.Location.X < 300)
            {
                Batman.Location = new Point(Batman.Location.X+1, 380);
            }
            else
            {
                batmsg.Visible = false;
                fire.Visible = true;
                manhole.Visible = true;
                started = true;
            }

            if (Zombei.Location.X < 50 && Batman.Location.X > 100)
            {
                Zombei.Location = new Point(Zombei.Location.X + 1, 380);
            }
        }

        void moveline(int speed)
        {
            
            //------------------------------
            if (n1.Location.X + 100 < 0)
            {
                n1.Location = new Point(760, n1.Location.Y);
            }
            else
            {
                n1.Location = new Point(n1.Location.X - speed, n1.Location.Y);
            }

            if (n2.Location.X + 100 < 0)
            {
                n2.Location = new Point(760, n2.Location.Y);
            }
            else
            {
                n2.Location = new Point(n2.Location.X - speed, n2.Location.Y);
            }

            if (n3.Location.X + 100 < 0)
            {
                n3.Location = new Point(760, n3.Location.Y);
            }
            else
            {
                n3.Location = new Point(n3.Location.X - speed, n3.Location.Y);
            }

            if (n4.Location.X + 100 < 0)
            {
                n4.Location = new Point(760, n4.Location.Y);
            }
            else
            {
                n4.Location = new Point(n4.Location.X - speed, n4.Location.Y);
            }

            if (n5.Location.X + 100 < 0)
            {
                n5.Location = new Point(760, n5.Location.Y);
            }
            else
            {
                n5.Location = new Point(n5.Location.X - speed, n5.Location.Y);
            }

            if (n6.Location.X + 100 < 0)
            {
                n6.Location = new Point(760, n6.Location.Y);
            }
            else
            {
                n6.Location = new Point(n6.Location.X - speed, n6.Location.Y);
            }

            if (shaswar.Location.X + 100 < 0)
            {
                shaswar.Location = new Point(760, shaswar.Location.Y);
            }
            else
            {
                shaswar.Location = new Point(shaswar.Location.X - speed, shaswar.Location.Y);
            }

        }

    }
}
